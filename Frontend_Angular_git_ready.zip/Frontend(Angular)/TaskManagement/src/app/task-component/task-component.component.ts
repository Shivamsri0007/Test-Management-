import { Component, OnInit } from '@angular/core';
import { TaskService } from './taskService';
import { Task } from '../Model/Task';

// path correct karna
// path correct karna

@Component({
  selector: 'apptask',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css']
})
export class TaskComponentComponent implements OnInit {

  keyword: string = ''; 
  task: Task = {} as Task;   // ya any bhi chal jaayega
  tasks: Task[] = [];        // store all tasks

  constructor(private taskService: TaskService) { }  // ✅ inject service

  ngOnInit(): void {
    this.loadTasks();       // component load hone par tasks fetch ho
  }

  // ✅ Load all tasks
  loadTasks() {
    this.taskService.getTasks().subscribe(res => {
      this.tasks = res;
    });
  }

  saveTask() {
    debugger
    if (this.task.taskId) {
      this.taskService.updateTask(this.task)
        .subscribe(() => {
          this.loadTasks();
          this.task = {} as Task;
        });
    } else {
      this.taskService.createTask(this.task)
        .subscribe(() => {
          this.loadTasks();
          this.task = {} as Task;
        });
    }
  }

  editTask(t: Task) {
    this.task = { ...t };
  }
 search(): void {
    if (!this.keyword) {
      this.loadTasks();
      return;
    }

    this.tasks = this.tasks.filter(t =>
      t.taskTitle.toLowerCase().includes(this.keyword.toLowerCase()) ||
      t.taskStatus.toLowerCase().includes(this.keyword.toLowerCase())
    );
  }

  deleteTask(id: number): void {
    // Remove task from tasks array
    this.tasks = this.tasks.filter(t => t.taskId !== id);

    // OR call API to delete from server
    console.log('Deleted Task with ID:', id);
  }
  getStatusClass(status: string) {
    return {
      'badge pending': status === 'Pending',
      'badge progress': status === 'In Progress',
      'badge completed': status === 'Completed'
    };
  }
  
}
