import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Task } from "../Model/Task";

@Injectable({ providedIn: 'root' })
export class TaskService {

  private apiUrl = 'https://localhost:7280/api/Task';

  constructor(private http: HttpClient) {}

  // GET: api/Task/GetTaskdetail
  getTasks() {
    return this.http.get<Task[]>(`${this.apiUrl}/GetTaskdetail`);
  }

  // POST: api/Task/CreateTask
  createTask(task: Task) {
    return this.http.post(`${this.apiUrl}/CreateTask`, task);
  }

  // GET: api/Task/{id}
  getTaskById(id: number) {
    return this.http.get<Task>(`${this.apiUrl}/${id}`);
  }

  // PUT: api/Task/{id}
  updateTask(task: Task) {
  return this.http.put(
    `${this.apiUrl}/UpdateTask/${task.taskId}`,
    task
  );
}

  // DELETE: api/Task/{id}
  deleteTask(id: number) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  // GET: api/Task/search?keyword=
  search(keyword: string) {
    return this.http.get<Task[]>(
      `${this.apiUrl}/search?keyword=${encodeURIComponent(keyword)}`
    );
  }
}
