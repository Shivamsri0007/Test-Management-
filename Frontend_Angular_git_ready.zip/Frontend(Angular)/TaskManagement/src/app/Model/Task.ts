export interface Task {
  taskId?: number;
  taskTitle: string;
  taskDescription: string;
  taskDueDate: Date;
  taskStatus: string;
  taskRemarks: string;
  createdByName: string;
  createdById: number;
  lastUpdatedByName: string;
  lastUpdatedById: number;
  CreatedOn:Date;
}
