﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace TaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly AppDbContext _context;
        public TaskController(AppDbContext context)
        {

            _context = context;
        }

        [HttpGet("GetTaskdetail")]
        public async Task<IActionResult> Get()
        {
            var tasks = await _context.Tasks.ToListAsync();
            return Ok(tasks);
        }


        [HttpPost("CreateTask")]
        public async Task<IActionResult> CreateTask(Task task)
        {
            task.CreatedOn = DateTime.Now;
            task.LastUpdatedOn = DateTime.Now;
            _context.Tasks.Add(task);
             _context.SaveChanges();
            return Ok(task);
        }
        [HttpGet("{id}")]

        public async Task<IActionResult> getTaskbyId(int id)
        {
            var res = await _context.Tasks.FindAsync(id);
            if (res == null)
            {
                return NotFound();
            }
            return Ok(res);

        }

        [HttpPut("UpdateTask/{id}")]
        public async Task<IActionResult> UpdateTask(int id, Task task)
        {

            var tasks = await _context.Tasks
                   .Where(x => x.TaskId == id)
                   .FirstOrDefaultAsync();
          if(tasks == null)
            {
                return NotFound();
            }
            tasks.TaskDescription = task.TaskDescription;
            tasks.TaskRemarks  = task.TaskRemarks;
            tasks.TaskStatus= task.TaskStatus;
            tasks.TaskTitle = task.TaskTitle;
            

            tasks.LastUpdatedOn = DateTime.Now;
            _context.Update(task);
            _context.SaveChangesAsync();
            
            return Ok(task);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return NotFound();

            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync();
            return Ok();
        }

       
        [HttpGet("search")]
        public async Task<IActionResult> Search(string keyword)
        {
            var result = await _context.Tasks
                .Where(t => t.TaskTitle.Contains(keyword)
                         || t.TaskStatus.Contains(keyword))
                .ToListAsync();

            return Ok(result);
        }
    }
}
